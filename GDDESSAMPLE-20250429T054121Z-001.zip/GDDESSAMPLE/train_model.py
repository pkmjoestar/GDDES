import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# Load the dataset
df = pd.read_csv("gynecology_data.csv")

# Convert categorical condition labels to numerical values
df["condition"] = df["condition"].astype("category").cat.codes  # Convert conditions to numbers

# Separate features (X) and target variable (y)
X = df.drop(columns=["condition"])  # Features (symptoms)
y = df["condition"]  # Target (condition)

# Split data into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a Random Forest model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Test the model
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"✅ Model Accuracy: {accuracy * 100:.2f}%")

# Save the trained model
import joblib
joblib.dump(model, "gynecology_model.pkl")

print("✅ Model saved as 'gynecology_model.pkl'!")