import tkinter as tk
from tkinter import messagebox, ttk, filedialog
import numpy as np
import joblib

# Load the trained model
model = joblib.load("gynecology_xgb_model.pkl")

# Condition mapping and explanations (example explanations)
condition_mapping = [
    "PCOS", "Endometriosis", "PID", "Ovarian Cyst", 
    "UTI", "Fibroids", "Cervicitis", "Vaginitis"
]
condition_explanations = {
    "PCOS": "A hormonal disorder causing enlarged ovaries with small cysts.",
    "Endometriosis": "A painful disorder where tissue similar to the uterine lining grows outside the uterus.",
    "PID": "An infection of the female reproductive organs, often caused by sexually transmitted bacteria.",
    "Ovarian Cyst": "Fluid-filled sacs within the ovary.",
    "UTI": "An infection in any part of the urinary system.",
    "Fibroids": "Noncancerous growths in the uterus.",
    "Cervicitis": "Inflammation of the cervix.",
    "Vaginitis": "Inflammation or infection of the vagina."
}

# List of symptoms (example list)
symptom_options = [
    "Irregular Periods", "Heavy Bleeding", "Pelvic Pain",
    "Painful Intercourse", "Unusual Discharge", "Frequent Urination",
    "Abdominal Bloating", "Weight Gain", "Acne", "Hair Loss",
    "Missed Periods", "Lower Back Pain"
]

# Create the main GUI window
root = tk.Tk()
root.title("Gynecological Condition Predictor")
root.geometry("500x750")
root.configure(bg="#f0f0f0")

# Title label
tk.Label(root, text="Gynecological Condition Predictor", font=("Helvetica", 16, "bold"), bg="#f0f0f0").pack(pady=10)

# Function to predict condition
def predict_condition():
    try:
        # Gather symptom selections (0 or 1 for each symptom; here we use checkboxes for simplicity)
        symptom_values = [var.get() for var in symptom_vars]
        age = int(age_entry.get())
        severity = int(severity_var.get())
        
        input_data = np.array([symptom_values + [age, severity]])
        predicted_num = int(model.predict(input_data)[0])
        predicted_condition = condition_mapping[predicted_num]
        explanation = condition_explanations.get(predicted_condition, "No explanation available.")
        
        result_text = f"Predicted Condition: {predicted_condition}\nExplanation: {explanation}"
        result_label.config(text=result_text, fg="green")
    except ValueError:
        messagebox.showerror("Input Error", "Please enter valid numerical values for Age and Severity.")

# Function to export results to a text file
def export_results():
    result = result_label.cget("text")
    if not result:
        messagebox.showwarning("No Result", "There is no result to export. Please run a prediction first.")
        return
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text files", ".txt"), ("All files", ".*")])
    if file_path:
        with open(file_path, "w") as file:
            file.write(result)
        messagebox.showinfo("Export Successful", f"Results exported to {file_path}")

# Frame for symptom checkboxes
frame = tk.Frame(root, bg="#f0f0f0")
frame.pack(pady=10)
symptom_vars = [tk.IntVar() for _ in symptom_options]
for i, symptom in enumerate(symptom_options):
    tk.Checkbutton(frame, text=symptom, variable=symptom_vars[i], bg="#f0f0f0").grid(row=i, column=0, sticky="w")

# Age input
tk.Label(root, text="Enter Your Age:", bg="#f0f0f0").pack(pady=5)
age_entry = tk.Entry(root)
age_entry.pack()

# Severity input using a drop-down
tk.Label(root, text="Select Severity (1-5):", bg="#f0f0f0").pack(pady=5)
severity_var = tk.StringVar(value="1")
severity_dropdown = ttk.Combobox(root, textvariable=severity_var, values=["1", "2", "3", "4", "5"], state="readonly")
severity_dropdown.pack()

# Predict Button
tk.Button(root, text="Predict Condition", command=predict_condition, bg="#4CAF50", fg="white", font=("Helvetica", 12)).pack(pady=15)

# Export Button
tk.Button(root, text="Export Results", command=export_results, bg="#2196F3", fg="white", font=("Helvetica", 12)).pack(pady=5)

# Reset and Exit Buttons
def reset_fields():
    for var in symptom_vars:
        var.set(0)
    age_entry.delete(0, tk.END)
    severity_var.set("1")
    result_label.config(text="")

tk.Button(root, text="Reset", command=reset_fields, bg="#FF9800", fg="white", font=("Helvetica", 12)).pack(pady=5)
tk.Button(root, text="Exit", command=root.quit, bg="#F44336", fg="white", font=("Helvetica", 12)).pack(pady=5)

# Result display
result_label = tk.Label(root, text="", font=("Helvetica", 14), bg="#f0f0f0", wraplength=400, justify="left")
result_label.pack(pady=20)

root.mainloop()