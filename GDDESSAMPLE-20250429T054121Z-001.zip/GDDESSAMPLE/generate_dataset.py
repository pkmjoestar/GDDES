import pandas as pd
import random
from faker import Faker

# Initialize Faker for generating fake patient data
fake = Faker()

# Define symptoms and conditions
symptoms = [
    "irregular_periods", "heavy_bleeding", "pelvic_pain", "painful_intercourse",
    "unusual_discharge", "frequent_urination", "abdominal_bloating", "weight_gain",
    "acne", "hair_loss", "missed_periods", "lower_back_pain"
]

# List of gynecological conditions
conditions = ["PCOS", "Endometriosis", "PID", "Ovarian Cyst", "UTI", "Fibroids", "Cervicitis", "Vaginitis"]

# Generate 500 fake patient records
data = []
for _ in range(500):  # Change this number to generate more cases
    patient = {symptom: random.randint(0, 1) for symptom in symptoms}  # Random 0 or 1
    patient["age"] = random.randint(18, 50)  # Age range
    patient["severity_score"] = random.randint(1, 5)  # Severity scale (1-5)
    patient["condition"] = random.choice(conditions)  # Random condition
    data.append(patient)

# Convert to DataFrame and save as CSV
df = pd.DataFrame(data)
df.to_csv("gynecology_data.csv", index=False)

print("✅ Dataset 'gynecology_data.csv' created successfully!")