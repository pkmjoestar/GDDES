import pandas as pd
import random
from faker import Faker

# Initialize Faker for any additional fake data (if needed)
fake = Faker()

# Define the list of symptoms (binary features: 0 = No, 1 = Yes)
symptoms = [
    "irregular_periods", "heavy_bleeding", "pelvic_pain", "painful_intercourse",
    "unusual_discharge", "frequent_urination", "abdominal_bloating", "weight_gain",
    "acne", "hair_loss", "missed_periods", "lower_back_pain"
]

# List of possible gynecological conditions
conditions = ["PCOS", "Endometriosis", "PID", "Ovarian Cyst", "UTI", "Fibroids", "Cervicitis", "Vaginitis"]

# Number of synthetic records to generate
num_records = 1000

data = []
for _ in range(num_records):
    record = {}
    # Assign each symptom a random binary value
    for symptom in symptoms:
        record[symptom] = random.randint(0, 1)
    # Random age between 18 and 50
    record["age"] = random.randint(18, 50)
    # Severity score between 1 and 5 (could represent overall symptom severity)
    record["severity_score"] = random.randint(1, 5)
    # Randomly choose a condition from the list
    record["condition"] = random.choice(conditions)
    data.append(record)

# Convert the list of records into a DataFrame
df = pd.DataFrame(data)

# Save the DataFrame to a CSV file
df.to_csv("synthetic_gynecology_data.csv", index=False)
print("Synthetic dataset saved as 'synthetic_gynecology_data.csv'")