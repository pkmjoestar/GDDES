import joblib
import numpy as np

# Load the trained model
model = joblib.load("gynecology_model.pkl")

# Define the symptoms (1 = Yes, 0 = No)
# Example: A user reports symptoms like irregular periods, pelvic pain, and bloating.
user_input = np.array([[0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 28, 3]])
# Make a prediction
predicted_condition = model.predict(user_input)

# Define condition mapping (match numerical output to actual condition names)
condition_mapping = ["PCOS", "Endometriosis", "PID", "Ovarian Cyst", "UTI", "Fibroids", "Cervicitis", "Vaginitis"]

# Get the predicted condition name
predicted_condition_name = condition_mapping[int(predicted_condition[0])]

print(f"✅ Predicted Condition: {predicted_condition_name}")