import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load the synthetic dataset
df = pd.read_csv("synthetic_gynecology_data.csv")

# Convert categorical target to numerical codes
df["condition"] = df["condition"].astype("category").cat.codes

# Separate features (X) and target (y)
X = df.drop(columns=["condition"])
y = df["condition"]

# Split the dataset into training and testing sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize the XGBoost classifier
model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)

# Train the model
model.fit(X_train, y_train)

# Make predictions on the test set
y_pred = model.predict(X_test)

# Evaluate the model accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"✅ Model Accuracy: {accuracy * 100:.2f}%")

# Optionally, save the trained model for later use
import joblib
joblib.dump(model, "gynecology_xgb_model.pkl")
print("✅ Model saved as 'gynecology_xgb_model.pkl'")